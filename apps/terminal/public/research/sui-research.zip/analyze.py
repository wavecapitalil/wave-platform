from pathlib import Path
import json, hashlib, warnings, platform
import numpy as np
import pandas as pd
import scipy
from scipy import stats
import statsmodels
import statsmodels.api as sm
from statsmodels.tsa.stattools import adfuller, kpss, coint
from statsmodels.stats.diagnostic import acorr_ljungbox, het_breuschpagan
from statsmodels.stats.stattools import durbin_watson
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.ticker import FuncFormatter

ROOT = Path(__file__).resolve().parent
rng = np.random.default_rng(20261103)
warnings.filterwarnings('ignore', category=UserWarning)
raw = {}
audit = {}
for name, file in [('price', 'Price.csv'), ('ratio', 'FDMC - Revenue.csv')]:
    path = ROOT / 'inputs' / file
    d = pd.read_csv(path, encoding='utf-8-sig')
    audit[name] = {'rows': len(d), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
    d.columns = ['date', name]
    d['date'] = pd.to_datetime(d['date'], errors='raise')
    d[name] = pd.to_numeric(d[name], errors='raise')
    audit[name].update(duplicate_dates=int(d.date.duplicated().sum()), missing_values=int(d.isna().sum().sum()))
    assert not d.date.duplicated().any(), 'Duplicate dates require explicit resolution'
    assert not d.isna().any().any(), 'Missing inputs require explicit resolution'
    assert (d[name] > 0).all(), 'Log models require positive values'
    raw[name] = d.sort_values('date')
outer = raw['price'].merge(raw['ratio'], on='date', how='outer', indicator=True, validate='one_to_one')
audit['alignment'] = outer['_merge'].value_counts().to_dict()
d = outer.loc[outer['_merge'] == 'both', ['date', 'price', 'ratio']].sort_values('date').reset_index(drop=True)
assert d.date.diff().dropna().eq(pd.Timedelta(days=1)).all(), 'Irregular dates require time based transformations'
d['log_price'] = np.log(d.price)
d['log_ratio'] = np.log(d.ratio)
d['price_change'] = d.price.diff()
d['ratio_change'] = d.ratio.diff()
d['price_log_return'] = d.log_price.diff()
d['ratio_log_change'] = d.log_ratio.diff()
d['time'] = np.arange(len(d))
d['price_divided_by_ratio'] = d.price / d.ratio
d.to_csv(ROOT / 'aligned data.csv', index=False)

models, fitted, corrs = [], {}, []
def fit(label, y, x, trend=None):
    frame = pd.DataFrame({'y': np.asarray(y), 'x': np.asarray(x)})
    if trend is not None: frame['time'] = np.asarray(trend)
    frame = frame.dropna()
    X = sm.add_constant(frame.drop(columns='y'))
    m = sm.OLS(frame.y, X).fit()
    fitted[label] = m
    for method, r in [('OLS', m), ('HC3', m.get_robustcov_results(cov_type='HC3', use_t=True))] + [
        (f'HAC {lag} days', m.get_robustcov_results(cov_type='HAC', maxlags=lag, use_correction=True, use_t=True)) for lag in [1,3,7,14]]:
        for j, term in enumerate(X.columns):
            ci = np.asarray(r.conf_int(alpha=.05))[j]
            models.append(dict(model=label, inference=method, term=term, n=len(frame), coefficient=np.asarray(r.params)[j], se=np.asarray(r.bse)[j], ci95_low=ci[0], ci95_high=ci[1], p=np.asarray(r.pvalues)[j], r_squared=m.rsquared))
    return m

def corr(label, x, y):
    a = pd.DataFrame({'x':np.asarray(x), 'y':np.asarray(y)}).dropna()
    r, p = stats.pearsonr(a.x, a.y)
    z = np.arctanh(np.clip(r,-.999999999,.999999999))
    bounds = np.tanh(z + np.array([-1,1])*stats.norm.ppf(.975)/np.sqrt(len(a)-3))
    s, sp = stats.spearmanr(a.x,a.y)
    corrs.append(dict(sample=label,n=len(a),pearson_r=r,pearson_p_iid=p,ci95_low_iid=bounds[0],ci95_high_iid=bounds[1],spearman_r=s,spearman_p_iid=sp))

fit('Levels',d.price,d.ratio)
fit('Log levels',d.log_price,d.log_ratio)
fit('Daily changes',d.price_change,d.ratio_change)
fit('Daily log changes',d.price_log_return,d.ratio_log_change)
fit('Levels with linear time',d.price,d.ratio,d.time)
fit('Log levels with linear time',d.log_price,d.log_ratio,d.time)
corr('Levels',d.ratio,d.price)
corr('Log levels',d.log_ratio,d.log_price)
corr('Daily changes',d.ratio_change,d.price_change)
corr('Daily log changes',d.ratio_log_change,d.price_log_return)
timeX=sm.add_constant(d.time)
corr('Linear trend removed',sm.OLS(d.ratio,timeX).fit().resid,sm.OLS(d.price,timeX).fit().resid)
for label, sub in [('First half', d.iloc[:len(d)//2]),('Second half',d.iloc[len(d)//2:])]:
    corr(label,sub.ratio,sub.price)
    fit(label,sub.price,sub.ratio)
    corr(label+' daily log changes',sub.log_ratio.diff(),sub.log_price.diff())
cooks=fitted['Levels'].get_influence().cooks_distance[0]
keep=cooks <= 4/len(d)
corr('Cook distance at most 4 divided by n',d.ratio[keep],d.price[keep])
fit('Influence filtered levels',d.price[keep],d.ratio[keep])
pd.DataFrame({'date':d.date,'cook_distance':cooks,'included_in_sensitivity':keep}).to_csv(ROOT/'influence.csv',index=False)
wx=stats.mstats.winsorize(d.ratio,limits=[.05,.05]); wy=stats.mstats.winsorize(d.price,limits=[.05,.05])
corr('Marginal winsorization 5 percent',wx,wy)
fit('Winsorized levels',wy,wx)
loo=np.array([stats.pearsonr(d.ratio.drop(i),d.price.drop(i)).statistic for i in d.index])

tests=[]
for col in ['price','ratio','log_price','log_ratio','price_log_return','ratio_log_change']:
    v=d[col].dropna()
    for trend in ['c','ct']:
        a=adfuller(v,maxlag=7,regression=trend,autolag='AIC')
        tests.append(dict(test='ADF',series=col,trend=trend,statistic=a[0],p=a[1],lags=a[2],n=a[3]))
        with warnings.catch_warnings():
            warnings.simplefilter('ignore')
            k=kpss(v,regression=trend,nlags='auto')
        tests.append(dict(test='KPSS',series=col,trend=trend,statistic=k[0],p=k[1],lags=k[2],n=len(v)))
for label,y,x in [('Levels',d.price,d.ratio),('Log levels',d.log_price,d.log_ratio)]:
    for trend in ['c','ct']:
        a=coint(y,x,trend=trend,maxlag=7,autolag='aic')
        tests.append(dict(test='Engle Granger',series=label,trend=trend,statistic=a[0],p=a[1],lags=None,n=len(d)))
for label in ['Levels','Daily log changes']:
    m=fitted[label]
    for lag,row in acorr_ljungbox(m.resid,lags=[1,7,14],return_df=True).iterrows():
        tests.append(dict(test='Ljung Box',series=label,trend='',statistic=row.lb_stat,p=row.lb_pvalue,lags=lag,n=m.nobs))
    b=het_breuschpagan(m.resid,m.model.exog)
    tests.append(dict(test='Breusch Pagan LM',series=label,trend='',statistic=b[0],p=b[1],lags=None,n=m.nobs))

# Paired circular moving block bootstrap preserves local dependence within pairs.
# Level intervals remain descriptive when stationarity is unsupported.
boot=[]
for label,a in [('Levels',d[['ratio','price']].to_numpy()),('Daily log changes',d[['ratio_log_change','price_log_return']].dropna().to_numpy())]:
    n=len(a)
    for block in [3,7,14]:
        rr=[]; bb=[]
        for _ in range(5000):
            starts=rng.integers(0,n,size=int(np.ceil(n/block)))
            idx=((starts[:,None]+np.arange(block))%n).ravel()[:n]
            x,y=a[idx].T
            rr.append(np.corrcoef(x,y)[0,1])
            bb.append(np.cov(x,y,ddof=1)[0,1]/np.var(x,ddof=1))
        for metric, vals in [('Pearson r',rr),('Slope',bb)]:
            lo,hi=np.quantile(vals,[.025,.975])
            boot.append(dict(sample=label,metric=metric,block_days=block,replicates=5000,ci95_low=lo,ci95_high=hi))
returns=d[['ratio_log_change','price_log_return']].dropna().to_numpy()
shift_r=np.array([np.corrcoef(np.roll(returns[:,0],s),returns[:,1])[0,1] for s in range(len(returns))])
shift_p=float(np.mean(np.abs(shift_r)>=abs(shift_r[0])))
pd.DataFrame({'circular_shift_days':np.arange(len(returns)),'r':shift_r}).to_csv(ROOT/'circular shift test.csv',index=False)
lagrows=[]
for lag in range(-7,8):
    pair=pd.DataFrame({'x':d.ratio_log_change.shift(lag),'y':d.price_log_return}).dropna()
    r,p=stats.pearsonr(pair.x,pair.y)
    lagrows.append(dict(ratio_lead_days=lag,n=len(pair),r=r,p_iid=p))
pd.DataFrame(lagrows).to_csv(ROOT/'exploratory lag correlations.csv',index=False)
pd.DataFrame(models).to_csv(ROOT/'regressions.csv',index=False)
pd.DataFrame(corrs).to_csv(ROOT/'correlations.csv',index=False)
pd.DataFrame(tests).to_csv(ROOT/'diagnostic tests.csv',index=False)
pd.DataFrame(boot).to_csv(ROOT/'block bootstrap.csv',index=False)
rolling_rows=[]
for end in range(89,len(d)):
    sub=d.iloc[end-89:end+1]
    m=sm.OLS(sub.price,sm.add_constant(sub.ratio)).fit()
    h=m.get_robustcov_results(cov_type='HAC',maxlags=7,use_correction=True,use_t=True)
    ci=h.conf_int()[1]
    rolling_rows.append(dict(window_start=str(sub.date.iloc[0].date()),window_end=str(sub.date.iloc[-1].date()),n=len(sub),pearson_r=sub.price.corr(sub.ratio),r_squared=m.rsquared,intercept=m.params.iloc[0],slope=m.params.iloc[1],slope_per_1000_ratio_units=m.params.iloc[1]*1000,slope_ci95_hac7_low=ci[0],slope_ci95_hac7_high=ci[1],slope_p_hac7=h.pvalues[1]))
    r=sub.price.corr(sub.ratio)
    rci=np.tanh(np.arctanh(r)+np.array([-1,1])*stats.norm.ppf(.975)/np.sqrt(len(sub)-3))
    rolling_rows[-1].update(correlation_ci95_iid_low=rci[0],correlation_ci95_iid_high=rci[1])
rolling90=pd.DataFrame(rolling_rows)
rolling90.to_csv(ROOT/'rolling 90 day results.csv',index=False)
audit.update(start=str(d.date.min().date()),end=str(d.date.max().date()),matched_n=len(d),excluded_in_influence_sensitivity=int((~keep).sum()),leave_one_out_r_min=float(loo.min()),leave_one_out_r_max=float(loo.max()),circular_shift_return_p=shift_p,durbin_watson_levels=float(durbin_watson(fitted['Levels'].resid)),versions={'python':platform.python_version(),'numpy':np.__version__,'pandas':pd.__version__,'scipy':scipy.__version__,'statsmodels':statsmodels.__version__,'matplotlib':matplotlib.__version__})
(ROOT/'audit.json').write_text(json.dumps(audit,indent=2,default=str))
(ROOT/'requirements.txt').write_text('\n'.join(f'{k}=={v}' for k,v in audit['versions'].items() if k!='python')+'\n')

# Publication charts use explicit scientific static output.
plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'white','axes.titleweight':'bold','axes.unicode_minus':False})
def signed(v,pos=None):
    return ('minus ' if v<0 else '')+f'{abs(v):g}'
def tidy(ax):
    ax.grid(alpha=.16)
    ax.xaxis.set_major_formatter(FuncFormatter(signed))
    ax.yaxis.set_major_formatter(FuncFormatter(signed))
def save(fig,name):
    for ax in fig.axes:
        if name != 'Rolling 90 day correlation and slope' and isinstance(ax.xaxis.converter, (mdates.DateConverter, mdates._SwitchableDateConverter)):
            ax.xaxis.set_major_locator(mdates.AutoDateLocator(minticks=4,maxticks=6))
            ax.xaxis.set_major_formatter(mdates.DateFormatter('%d %b'))
    fig.savefig(ROOT/'charts'/f'{name}.png',dpi=200,bbox_inches='tight')
    fig.savefig(ROOT/'charts'/f'{name}.svg',bbox_inches='tight')
    plt.close(fig)

fig,ax=plt.subplots(figsize=(10,5.5),layout='constrained')
ax.plot(d.date,d.price/d.price.iloc[0]*100,label='Price',color='#1267a6',linewidth=2)
ax.plot(d.date,d.ratio/d.ratio.iloc[0]*100,label='FDMC to revenue',color='#b34d19',linewidth=2,linestyle=':')
ax.set(title='SUI daily series',ylabel='Index, first observation equals 100',xlabel='2026')
ax.legend(); ax.grid(alpha=.2);fig.autofmt_xdate();save(fig,'Daily series')

fig,axs=plt.subplots(1,2,figsize=(13,5.5),layout='constrained')
for ax,label,x,y,xlabel,ylabel in [
    (axs[0],'Levels',d.ratio,d.price,'FDMC to revenue ratio, supplied units','Price, supplied units'),
    (axs[1],'Daily log changes',d.ratio_log_change.dropna()*100,d.price_log_return.dropna()*100,'Daily log change in ratio, percent','Daily price log return, percent')]:
    m=sm.OLS(y,sm.add_constant(x)).fit()
    xx=np.linspace(min(x),max(x),150); X=sm.add_constant(xx)
    robust=m.get_robustcov_results(cov_type='HAC',maxlags=7,use_correction=True,use_t=True)
    pred=X@np.asarray(m.params)
    se=np.sqrt(np.einsum('ij,jk,ik->i',X,robust.cov_params(),X))
    delta=stats.t.ppf(.975,m.df_resid)*se
    ax.scatter(x,y,c=np.arange(len(x)),cmap='viridis',s=24,alpha=.8)
    ax.plot(xx,pred,color='#ad4b20',label='OLS fitted mean')
    ax.fill_between(xx,pred-delta,pred+delta,color='#ad4b20',alpha=.15,label='95% HAC mean interval, 7 days')
    ax.set(title=label,xlabel=xlabel,ylabel=ylabel);tidy(ax)
    ax.legend(fontsize=8,loc='best')
fig.suptitle('SUI relationship in levels and daily changes\nPoint colors run from earlier dates in purple to later dates in yellow',fontsize=13)
save(fig,'Regression comparison')

fig,axs=plt.subplots(2,1,figsize=(10,7),layout='constrained')
rolling=d.price.rolling(30).corr(d.ratio)
axs[0].plot(d.date,rolling,color='#1267a6');axs[0].axhline(0,color='gray',linewidth=.8)
axs[0].set(title='Pearson correlation in rolling windows of 30 days',ylabel='Pearson r',ylim=(-1,1));axs[0].yaxis.set_major_formatter(FuncFormatter(signed));axs[0].grid(alpha=.2)
axs[1].plot(d.date,fitted['Levels'].resid,color='#b34d19');axs[1].axhline(0,color='gray',linewidth=.8)
axs[1].set(title='Level regression residuals',ylabel='Price residual, supplied units',xlabel='2026');axs[1].yaxis.set_major_formatter(FuncFormatter(signed));axs[1].grid(alpha=.2)
save(fig,'Stability and residuals')

fig,axs=plt.subplots(2,1,figsize=(10,7),layout='constrained')
ends=pd.to_datetime(rolling90.window_end)
axs[0].plot(ends,rolling90.pearson_r,marker='o',color='#1267a6')
axs[0].set(title='Rolling Pearson correlation',ylabel='Pearson r',ylim=(-1,1))
axs[0].axhline(0,color='gray',linewidth=.8)
coef=rolling90.slope_per_1000_ratio_units
low=rolling90.slope_ci95_hac7_low*1000; high=rolling90.slope_ci95_hac7_high*1000
axs[1].errorbar(ends,coef,yerr=[coef-low,high-coef],fmt='o',capsize=5,color='#b34d19')
axs[1].set(title='Rolling OLS slope with 95% HAC intervals, 7 days',ylabel='Price change per 1,000 ratio units',xlabel='Window ending date in 2026')
axs[1].axhline(0,color='gray',linewidth=.8)
for ax in axs:
    ax.set_xticks(ends, [v.strftime('%d %b') for v in ends])
    ax.yaxis.set_major_formatter(FuncFormatter(signed));ax.grid(alpha=.2)
fig.suptitle('Three month approximation, complete windows of 90 daily observations\nOnly two complete windows are available in the supplied history',fontsize=13)
save(fig,'Rolling 90 day correlation and slope')
print(json.dumps(audit,indent=2))
print(pd.DataFrame(corrs).to_string(index=False))
print(pd.DataFrame(models).query("term=='x' and inference=='HAC 7 days'").to_string(index=False))
print(pd.DataFrame(tests).to_string(index=False))
print(pd.DataFrame(boot).to_string(index=False))
