from pathlib import Path
import json,base64,io,warnings
import numpy as np,pandas as pd
from scipy import stats
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.dates as md
from matplotlib.ticker import FuncFormatter
from bidi.algorithm import get_display as he
R=Path(__file__).resolve().parent
D=pd.read_csv(R/'aligned data.csv',parse_dates=['date'])
pr=D.price_log_return
D['prior_vol']=pr.rolling(7,min_periods=7).std().shift(1)
D['vol_baseline']=D.prior_vol.expanding(min_periods=14).median().shift(1)
D['prior_price_direction']=D.log_price.shift(1)-D.log_price.shift(8)
D['prior_ratio_direction']=D.log_ratio.shift(1)-D.log_ratio.shift(8)
D['prior_move']=pr.abs().shift(1)
D['move_baseline']=D.prior_move.expanding(min_periods=14).median().shift(1)
factors={'volatility':('prior_vol','vol_baseline','תנודתיות קודמת גבוהה','תנודתיות קודמת נמוכה'), 'price direction':('prior_price_direction',0,'מחיר במגמת עלייה קודמת','מחיר במגמה קודמת ללא עלייה'), 'ratio direction':('prior_ratio_direction',0,'יחס במגמת עלייה קודמת','יחס במגמה קודמת ללא עלייה'), 'move size':('prior_move','move_baseline','תנועה יומית קודמת גדולה','תנועה יומית קודמת קטנה')}
for k,(v,b,*_) in factors.items():
 base=D[b] if isinstance(b,str) else b
 D[k]=np.where(D[v].notna() & (D[b].notna() if isinstance(b,str) else True), (D[v]>base).astype(float),np.nan)
regimes={'all':('כל התצפיות',np.ones(len(D),dtype=bool))}
for factor in ['volatility','price direction']:
 for v in [1,0]:
  regimes[f'{factor} {v}']=(factors[factor][2 if v else 3],D[factor].eq(v).to_numpy())

def calc(x,y,mask,lag):
 ok=np.isfinite(x)&np.isfinite(y)&mask;n=int(ok.sum())
 if n<4 or np.var(x[ok])<1e-24:return None
 X=np.column_stack([np.ones(n),x[ok]]);Y=y[ok];inv=np.linalg.inv(X.T@X);beta=inv@X.T@Y
 res=Y-X@beta;z=np.zeros((len(x),2));z[ok]=X*res[:,None];S=z.T@z
 for j in range(1,min(lag,len(x)-1)+1):
  C=z[j:].T@z[:-j];S+=(1-j/(lag+1))*(C+C.T)
 se=np.sqrt(max(0,(inv@S@inv*n/(n-2))[1,1]));q=stats.t.ppf(.975,n-2)
 return dict(n=n,r=float(np.corrcoef(x[ok],Y)[0,1]),slope=float(beta[1]),low=float(beta[1]-q*se),high=float(beta[1]+q*se))

rolling=[];images={};last={};rng=np.random.default_rng(20261104)
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False})
def fmt(v,pos=None):return he(('מינוס ' if v<0 else '')+f'{abs(v):.3g}')
colors={7:'#1267a6',30:'#b44c18',60:'#237854',90:'#7750a2'}
for basis in ['levels','changes']:
 x=D.ratio.to_numpy() if basis=='levels' else D.ratio_log_change.to_numpy()
 y=D.price.to_numpy() if basis=='levels' else D.price_log_return.to_numpy()
 for regime,(name,mask) in regimes.items():
  series={}
  for w in [7,30,60,90]:
   s=[]
   # Changes require w observed daily differences, hence w+1 original dates.
   first=w-1 if basis=='levels' else w
   for end in range(first,len(D)):
    start=end-w+1;a=calc(x[start:end+1],y[start:end+1],mask[start:end+1],min(7,w-1))
    row=dict(basis=basis,regime=regime,window=w,start=str(D.date.iloc[start].date()),end=str(D.date.iloc[end].date()),**(a or dict(n=int((mask[start:end+1]&np.isfinite(x[start:end+1])&np.isfinite(y[start:end+1])).sum()),r=None,slope=None,low=None,high=None)))
    rolling.append(row);s.append(row)
   series[w]=s
  for choice in ['compare',7,30,60,90]:
   fig,axs=plt.subplots(2,1,figsize=(10,6.5),layout='constrained')
   windows=[7,30,60,90] if choice=='compare' else [choice]
   shown=[]
   for w in windows:
    s=series[w];valid=[a for a in s if a['r'] is not None]
    if not valid:continue
    dates=pd.to_datetime([a['end'] for a in s]);rr=np.array([a['r'] if a['r'] is not None else np.nan for a in s]);scale=1000 if basis=='levels' else 1
    slope=np.array([a['slope'] if a['slope'] is not None else np.nan for a in s])*scale
    axs[0].plot(dates,rr,label=he(f'{w} ימים'),color=colors[w],marker='o' if len(s)<4 else None,markersize=4)
    axs[1].plot(dates,slope,label=he(f'{w} ימים'),color=colors[w],marker='o' if len(s)<4 else None,markersize=4)
    if choice!='compare':
     low=np.array([a['low'] if a['low'] is not None else np.nan for a in s])*scale;high=np.array([a['high'] if a['high'] is not None else np.nan for a in s])*scale
     axs[1].fill_between(dates,low,high,color=colors[w],alpha=.15,label=he('רווח סמך 95% לשיפוע, HAC'))
    shown.append(valid[-1])
   axs[0].set(ylabel=he('מתאם פירסון'),ylim=(-1.05,1.05),title=he('מתאם בחלון מתגלגל'))
   axs[1].set(ylabel=he('יחידות מחיר לכל 1,000 יחידות יחס' if basis=='levels' else 'שינוי לוגריתמי במחיר ביחס לשינוי ביחס'),title=he('שיפוע רגרסיה בחלון מתגלגל'),xlabel=he('מועד סיום החלון בשנת 2026'))
   for ax in axs:
    ax.axhline(0,color='#687985',linewidth=.8);ax.grid(alpha=.16);ax.yaxis.set_major_formatter(FuncFormatter(fmt))
    ax.xaxis.set_major_locator(md.AutoDateLocator(minticks=3,maxticks=5));ax.xaxis.set_major_formatter(md.DateFormatter('%d/%m'))
    if shown:ax.legend(fontsize=8,ncol=2,loc='best')
   if not shown:
    axs[0].text(.5,.5,he('אין מספיק תצפיות מתאימות'),transform=axs[0].transAxes,ha='center')
   fig.suptitle(he(('רמות המחיר והיחס' if basis=='levels' else 'שינויים לוגריתמיים יומיים')+' · '+name),fontsize=13)
   b=io.BytesIO();fig.savefig(b,format='png',dpi=125,bbox_inches='tight');plt.close(fig)
   key=f'{basis}|{regime}|{choice}';images[key]=base64.b64encode(b.getvalue()).decode();last[key]=shown
pd.DataFrame(rolling).to_csv(R/'rolling all windows.csv',index=False)

variant=[]
for basis in ['levels','changes']:
 x=D.ratio.to_numpy() if basis=='levels' else D.ratio_log_change.to_numpy();y=D.price.to_numpy() if basis=='levels' else D.price_log_return.to_numpy()
 for fac,(_,_,yes,no) in factors.items():
  g=D[fac].to_numpy();mask=np.isfinite(g)&np.isfinite(x)&np.isfinite(y)
  r1=np.corrcoef(x[mask&(g==1)],y[mask&(g==1)])[0,1];r0=np.corrcoef(x[mask&(g==0)],y[mask&(g==0)])[0,1]
  diffs=[]
  for _ in range(3000):
   starts=rng.integers(0,len(D),size=int(np.ceil(len(D)/7)));idx=((starts[:,None]+np.arange(7))%len(D)).ravel()[:len(D)]
   a=idx[mask[idx]&(g[idx]==1)];b=idx[mask[idx]&(g[idx]==0)]
   if min(len(a),len(b))<8:continue
   diffs.append(abs(np.corrcoef(x[a],y[a])[0,1])-abs(np.corrcoef(x[b],y[b])[0,1]))
  lo,hi=np.quantile(diffs,[.00625,.99375]) # 98.75 percent, Bonferroni for four contrasts within a basis
  variant.append(dict(basis=basis,factor=fac,group1=yes,group0=no,n1=int((mask&(g==1)).sum()),n0=int((mask&(g==0)).sum()),r1=float(r1),r0=float(r0),absolute_r_difference=float(abs(r1)-abs(r0)),ci98_75_low=float(lo),ci98_75_high=float(hi),bootstrap_valid=len(diffs)))
pd.DataFrame(variant).to_csv(R/'variant comparisons.csv',index=False)
D.to_csv(R/'regime features.csv',index=False)
payload=dict(images=images,last=last,variants=variant,regimes={k:v[0] for k,v in regimes.items()},rolling=rolling)
(R/'rolling explorer data.json').write_text(json.dumps(payload,allow_nan=False))
print(pd.DataFrame(variant).to_string(index=False))
print('Rendered',len(images),'scientific chart states')
